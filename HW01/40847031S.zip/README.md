HW01
===

40847031S 郭泰維

## 
[Problem Website](https://www.codingame.com/ide/puzzle/a-childs-play)

## Build
use `make` to compile this project, also support `make clean`

## Run
run `./main` to execute